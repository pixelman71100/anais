<?php
	
	// Controller utilisée pour afficher le template dans la boutique
	class Ns_MonModuleDisplayModuleFrontController extends ModuleFrontController
	{
	    public function initContent()
	    {
	    	// Exécute la méthode initContent du parent ModuleFrontController
	        parent::initContent();
	        // Et défini le template à utiliser
	        $this->setTemplate('module:ns_monmodule/views/templates/front/display.tpl');
	    }
	}